# Part 3: Run optimization and analyze results
print("\n=== RUNNING OPTIMIZATION ALGORITHMS ===")

# Initialize optimizer
optimizer = BrachytherapyOptimizer(calculator, prescription_dose=600.0)

# Calculate initial plan quality
print("\n--- Initial Plan Analysis ---")
initial_target_doses = []
initial_oar_doses = []

for point in initial_plan.target_points:
    dose = initial_plan.calculate_total_dose(point, calculator)
    initial_target_doses.append(dose)

for point in initial_plan.oar_points:
    dose = initial_plan.calculate_total_dose(point, calculator)
    initial_oar_doses.append(dose)

print(f"Initial target dose statistics:")
print(f"  Mean: {np.mean(initial_target_doses):.1f} cGy")
print(f"  Min:  {np.min(initial_target_doses):.1f} cGy")
print(f"  Max:  {np.max(initial_target_doses):.1f} cGy")
print(f"  Std:  {np.std(initial_target_doses):.1f} cGy")

print(f"\nInitial OAR dose statistics:")
print(f"  Mean: {np.mean(initial_oar_doses):.1f} cGy")
print(f"  Min:  {np.min(initial_oar_doses):.1f} cGy")
print(f"  Max:  {np.max(initial_oar_doses):.1f} cGy")
print(f"  Std:  {np.std(initial_oar_doses):.1f} cGy")

# Run IPSA-style optimization
print(f"\n--- Running IPSA-Style Optimization ---")
try:
    optimized_plan_ipsa = optimizer.optimize_ipsa_style(initial_plan, max_iterations=50)
    
    # Analyze optimized plan
    print("\n--- Optimized Plan Analysis (IPSA) ---")
    optimized_target_doses = []
    optimized_oar_doses = []

    for point in optimized_plan_ipsa.target_points:
        dose = optimized_plan_ipsa.calculate_total_dose(point, calculator)
        optimized_target_doses.append(dose)

    for point in optimized_plan_ipsa.oar_points:
        dose = optimized_plan_ipsa.calculate_total_dose(point, calculator)
        optimized_oar_doses.append(dose)

    print(f"Optimized target dose statistics:")
    print(f"  Mean: {np.mean(optimized_target_doses):.1f} cGy")
    print(f"  Min:  {np.min(optimized_target_doses):.1f} cGy")
    print(f"  Max:  {np.max(optimized_target_doses):.1f} cGy")
    print(f"  Std:  {np.std(optimized_target_doses):.1f} cGy")
    print(f"  Coverage (≥95% Rx): {np.sum(np.array(optimized_target_doses) >= 0.95*600)/len(optimized_target_doses)*100:.1f}%")

    print(f"\nOptimized OAR dose statistics:")
    print(f"  Mean: {np.mean(optimized_oar_doses):.1f} cGy")
    print(f"  Min:  {np.min(optimized_oar_doses):.1f} cGy")
    print(f"  Max:  {np.max(optimized_oar_doses):.1f} cGy")
    print(f"  Std:  {np.std(optimized_oar_doses):.1f} cGy")
    print(f"  Sparing (≤70% Rx): {np.sum(np.array(optimized_oar_doses) <= 0.70*600)/len(optimized_oar_doses)*100:.1f}%")

    print(f"\nOptimized dwell times:")
    print(f"  Total time: {sum(optimized_plan_ipsa.dwell_times):.1f} seconds")
    print(f"  Mean time:  {np.mean(optimized_plan_ipsa.dwell_times):.1f} seconds")
    print(f"  Active positions: {np.sum(np.array(optimized_plan_ipsa.dwell_times) > 1.0)} / {len(optimized_plan_ipsa.dwell_times)}")

except Exception as e:
    print(f"IPSA optimization failed: {e}")
    optimized_plan_ipsa = initial_plan

# Prepare data for analysis and visualization
print("\n=== PREPARING ANALYSIS DATA ===")

# Create dose analysis summary
analysis_data = {
    'plan_type': ['Initial', 'IPSA-Optimized'],
    'target_mean_dose': [np.mean(initial_target_doses), np.mean(optimized_target_doses) if 'optimized_target_doses' in locals() else np.mean(initial_target_doses)],
    'target_min_dose': [np.min(initial_target_doses), np.min(optimized_target_doses) if 'optimized_target_doses' in locals() else np.min(initial_target_doses)],
    'oar_mean_dose': [np.mean(initial_oar_doses), np.mean(optimized_oar_doses) if 'optimized_oar_doses' in locals() else np.mean(initial_oar_doses)],
    'total_treatment_time': [sum(initial_plan.dwell_times), sum(optimized_plan_ipsa.dwell_times)]
}

analysis_df = pd.DataFrame(analysis_data)
print("\nDose Analysis Summary:")
print(analysis_df.to_string(index=False, float_format='%.1f'))

# Calculate clinical metrics
def calculate_clinical_metrics(target_doses, oar_doses, prescription_dose=600.0):
    """Calculate standard clinical metrics for brachytherapy"""
    metrics = {}
    
    # Target coverage metrics
    metrics['D90'] = np.percentile(target_doses, 10)  # Minimum dose to 90% of target
    metrics['D95'] = np.percentile(target_doses, 5)   # Minimum dose to 95% of target
    metrics['V100'] = np.sum(np.array(target_doses) >= prescription_dose) / len(target_doses) * 100
    metrics['V150'] = np.sum(np.array(target_doses) >= 1.5*prescription_dose) / len(target_doses) * 100
    
    # OAR metrics
    metrics['OAR_D2cc'] = np.percentile(oar_doses, 80)  # Approximate D2cc (dose to 2cc volume)
    metrics['OAR_mean'] = np.mean(oar_doses)
    
    return metrics

initial_metrics = calculate_clinical_metrics(initial_target_doses, initial_oar_doses)
if 'optimized_target_doses' in locals():
    optimized_metrics = calculate_clinical_metrics(optimized_target_doses, optimized_oar_doses)
else:
    optimized_metrics = initial_metrics

print("\n--- Clinical Metrics Comparison ---")
print("Metric                Initial    Optimized    Improvement")
print("-" * 55)
print(f"Target D90 (cGy)     {initial_metrics['D90']:8.1f}   {optimized_metrics['D90']:8.1f}   {optimized_metrics['D90']-initial_metrics['D90']:+8.1f}")
print(f"Target V100 (%)      {initial_metrics['V100']:8.1f}   {optimized_metrics['V100']:8.1f}   {optimized_metrics['V100']-initial_metrics['V100']:+8.1f}")
print(f"OAR mean (cGy)       {initial_metrics['OAR_mean']:8.1f}   {optimized_metrics['OAR_mean']:8.1f}   {optimized_metrics['OAR_mean']-initial_metrics['OAR_mean']:+8.1f}")
print(f"V150 hot spots (%)   {initial_metrics['V150']:8.1f}   {optimized_metrics['V150']:8.1f}   {optimized_metrics['V150']-initial_metrics['V150']:+8.1f}")

print("\n✓ Optimization and analysis completed successfully!")