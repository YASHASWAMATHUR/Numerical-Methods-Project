# Part 4: Create comprehensive dose visualization and save project files
print("\n=== CREATING DOSE DISTRIBUTION VISUALIZATION ===")

# Create 3D dose distribution visualization data
def create_dose_grid(plan, calculator, x_range=(-30, 30), y_range=(-15, 15), z_range=(-25, 25), resolution=5):
    """Create 3D dose distribution grid"""
    x_coords = range(x_range[0], x_range[1]+1, resolution)
    y_coords = range(y_range[0], y_range[1]+1, resolution)  
    z_coords = range(z_range[0], z_range[1]+1, resolution)
    
    dose_data = []
    
    for x in x_coords:
        for y in y_coords:
            for z in z_coords:
                point = (float(x), float(y), float(z))
                dose = plan.calculate_total_dose(point, calculator)
                dose_data.append({
                    'x': x, 'y': y, 'z': z, 'dose': dose
                })
    
    return pd.DataFrame(dose_data)

print("Generating dose distribution grid for optimized plan...")
dose_grid_df = create_dose_grid(optimized_plan_ipsa, calculator, resolution=10)

# Save dose grid data
dose_grid_df.to_csv('dose_distribution_data.csv', index=False)
print(f"✓ Saved dose distribution data: {len(dose_grid_df)} points")

# Create dose-volume histogram data for visualization
def create_dvh_data(target_doses, oar_doses, prescription_dose=600.0):
    """Create dose-volume histogram data"""
    # Combine all doses
    all_doses = list(target_doses) + list(oar_doses)
    dose_bins = np.linspace(0, max(all_doses), 100)
    
    target_dvh = []
    oar_dvh = []
    
    for dose_level in dose_bins:
        target_volume_pct = np.sum(np.array(target_doses) >= dose_level) / len(target_doses) * 100
        oar_volume_pct = np.sum(np.array(oar_doses) >= dose_level) / len(oar_doses) * 100
        
        target_dvh.append(target_volume_pct)
        oar_dvh.append(oar_volume_pct)
    
    return pd.DataFrame({
        'dose_cGy': dose_bins,
        'target_volume_percent': target_dvh,
        'oar_volume_percent': oar_dvh
    })

dvh_data = create_dvh_data(optimized_target_doses, optimized_oar_doses)
dvh_data.to_csv('dose_volume_histogram.csv', index=False)
print("✓ Saved dose-volume histogram data")

# Create summary report
print("\n=== GENERATING PROJECT SUMMARY REPORT ===")

summary_report = f"""
BRACHYTHERAPY DOSE PLANNING AND OPTIMIZATION MINI PROJECT
========================================================

PROJECT OVERVIEW:
This project implements a complete brachytherapy treatment planning and optimization system
using numerical methods including TG-43 dose calculation and IPSA-style optimization.

IMPLEMENTATION COMPONENTS:
1. TG-43 Dose Calculation Algorithm
2. Linear Penalty Model (LPM) Optimization
3. IPSA-style optimization using L-BFGS-B
4. Clinical metrics evaluation
5. 3D dose distribution analysis

CLINICAL CASE:
- Simulated prostate HDR brachytherapy
- 2 catheters with {len(all_dwell_positions)} dwell positions
- {len(target_points)} target volume sampling points
- {len(oar_points)} organ-at-risk sampling points
- Prescription dose: {optimizer.prescription_dose} cGy

OPTIMIZATION RESULTS:
==================

Initial Plan Performance:
- Target mean dose: {np.mean(initial_target_doses):.1f} cGy
- Target minimum dose: {np.min(initial_target_doses):.1f} cGy  
- OAR mean dose: {np.mean(initial_oar_doses):.1f} cGy
- Total treatment time: {sum(initial_plan.dwell_times):.1f} seconds
- V100 coverage: {initial_metrics['V100']:.1f}%

IPSA-Optimized Plan Performance:
- Target mean dose: {np.mean(optimized_target_doses):.1f} cGy
- Target minimum dose: {np.min(optimized_target_doses):.1f} cGy
- OAR mean dose: {np.mean(optimized_oar_doses):.1f} cGy  
- Total treatment time: {sum(optimized_plan_ipsa.dwell_times):.1f} seconds
- V100 coverage: {optimized_metrics['V100']:.1f}%

IMPROVEMENT METRICS:
- OAR dose reduction: {initial_metrics['OAR_mean'] - optimized_metrics['OAR_mean']:.1f} cGy ({(initial_metrics['OAR_mean'] - optimized_metrics['OAR_mean'])/initial_metrics['OAR_mean']*100:.1f}%)
- Hot spot reduction (V150): {initial_metrics['V150'] - optimized_metrics['V150']:.1f}%
- Treatment time optimization: {sum(initial_plan.dwell_times) - sum(optimized_plan_ipsa.dwell_times):.1f} seconds saved

CLINICAL QUALITY INDICATORS:
- Target D90: {optimized_metrics['D90']:.1f} cGy
- Target V100: {optimized_metrics['V100']:.1f}%
- OAR sparing achieved: {np.sum(np.array(optimized_oar_doses) <= 0.70*600)/len(optimized_oar_doses)*100:.1f}%

NUMERICAL METHODS EMPLOYED:
1. TG-43 dose calculation with interpolation (SciPy interp1d)
2. L-BFGS-B constrained optimization (SciPy minimize)
3. Linear algebra operations (NumPy)
4. Statistical analysis and metrics (NumPy, Pandas)

FILES GENERATED:
- dose_distribution_data.csv: 3D dose grid data
- dose_volume_histogram.csv: DVH analysis data
- dwell_times_analysis.csv: Optimized dwell time results
- project_summary_report.txt: This summary

FUTURE ENHANCEMENTS:
1. Implementation of advanced optimization algorithms (HIPO, evolutionary methods)
2. Monte Carlo dose calculation for improved accuracy
3. Multi-objective optimization for Pareto-optimal solutions
4. Real patient anatomy integration
5. Uncertainty and robustness analysis

Generated on: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

# Save summary report
with open('project_summary_report.txt', 'w') as f:
    f.write(summary_report)

print("✓ Generated comprehensive project summary report")

# Create dwell times analysis
dwell_analysis = pd.DataFrame({
    'channel': [pos.channel for pos in optimized_plan_ipsa.dwell_positions],
    'position': [pos.position_number for pos in optimized_plan_ipsa.dwell_positions],
    'x_mm': [pos.x for pos in optimized_plan_ipsa.dwell_positions],
    'y_mm': [pos.y for pos in optimized_plan_ipsa.dwell_positions], 
    'z_mm': [pos.z for pos in optimized_plan_ipsa.dwell_positions],
    'initial_time_sec': initial_plan.dwell_times,
    'optimized_time_sec': optimized_plan_ipsa.dwell_times,
    'time_difference_sec': [opt - init for opt, init in zip(optimized_plan_ipsa.dwell_times, initial_plan.dwell_times)]
})

dwell_analysis.to_csv('dwell_times_analysis.csv', index=False)
print("✓ Saved dwell times analysis")

# Final project statistics
print(f"\n=== PROJECT COMPLETION SUMMARY ===")
print(f"✓ Implemented TG-43 dose calculation algorithm")
print(f"✓ Developed IPSA-style optimization framework") 
print(f"✓ Created sample clinical case with {len(all_dwell_positions)} dwell positions")
print(f"✓ Generated optimization results and analysis")
print(f"✓ Achieved {(initial_metrics['OAR_mean'] - optimized_metrics['OAR_mean'])/initial_metrics['OAR_mean']*100:.1f}% OAR dose reduction")
print(f"✓ Maintained {optimized_metrics['V100']:.1f}% target coverage")
print(f"✓ Created comprehensive documentation and data files")

print(f"\nProject files created:")
print(f"- dose_distribution_data.csv ({len(dose_grid_df)} dose points)")
print(f"- dose_volume_histogram.csv ({len(dvh_data)} DVH points)") 
print(f"- dwell_times_analysis.csv ({len(dwell_analysis)} positions)")
print(f"- project_summary_report.txt (detailed report)")

print(f"\n🎉 BRACHYTHERAPY OPTIMIZATION MINI PROJECT COMPLETED SUCCESSFULLY! 🎉")