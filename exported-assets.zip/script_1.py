# Fix the TG-43 implementation with proper interpolation
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize, differential_evolution
from scipy.interpolate import interp1d
import pandas as pd
from dataclasses import dataclass
from typing import List, Tuple, Dict
import json

print("=== BRACHYTHERAPY DOSE PLANNING AND OPTIMIZATION MINI PROJECT ===")
print("Implementing corrected TG-43 dose calculation...")

# Define data structures for brachytherapy planning
@dataclass
class DwellPosition:
    """Represents a dwell position in a catheter"""
    x: float  # mm
    y: float  # mm  
    z: float  # mm
    channel: int
    position_number: int

@dataclass
class SourceData:
    """TG-43 source specification data for Ir-192"""
    air_kerma_strength: float  # U (micro Gy m^2/h)
    dose_rate_constant: float  # Lambda (cGy/h/U)
    radial_dose_function_data: Dict  # g(r) vs r
    anisotropy_function_data: Dict   # F(r,theta) vs r,theta

# Create TG-43 source specification data for Ir-192 (typical HDR source)
ir192_source_data = SourceData(
    air_kerma_strength=40000,  # 40,000 U typical for new source
    dose_rate_constant=1.115,   # cGy/h/U for Ir-192
    radial_dose_function_data={
        # Distance (cm) : g(r) values
        0.1: 1.000, 0.25: 1.000, 0.5: 0.994, 0.75: 0.987, 1.0: 0.979,
        1.5: 0.964, 2.0: 0.948, 2.5: 0.932, 3.0: 0.915, 4.0: 0.881,
        5.0: 0.847, 6.0: 0.813, 7.0: 0.779, 8.0: 0.746, 10.0: 0.683
    },
    anisotropy_function_data={
        # Simplified anisotropy data: theta_deg: F(theta) (assumed r-independent for simplicity)
        0: 0.70, 10: 0.77, 30: 0.94, 45: 0.97, 60: 0.99, 90: 1.00,
        120: 0.99, 135: 0.97, 150: 0.94, 170: 0.77, 180: 0.70
    }
)

class TG43DoseCalculator:
    """Implementation of AAPM TG-43 dose calculation formalism"""
    
    def __init__(self, source_data: SourceData):
        self.source_data = source_data
        self.setup_interpolators()
    
    def setup_interpolators(self):
        """Setup interpolation functions for TG-43 parameters"""
        # Radial dose function interpolator
        r_values = np.array(list(self.source_data.radial_dose_function_data.keys()))
        g_values = np.array(list(self.source_data.radial_dose_function_data.values()))
        self.radial_dose_interp = interp1d(r_values, g_values, kind='linear', 
                                         bounds_error=False, fill_value=(g_values[0], g_values[-1]))
        
        # Anisotropy function interpolator
        theta_values = np.array(list(self.source_data.anisotropy_function_data.keys()))
        f_values = np.array(list(self.source_data.anisotropy_function_data.values()))
        self.anisotropy_interp = interp1d(theta_values, f_values, kind='linear',
                                        bounds_error=False, fill_value=(f_values[0], f_values[-1]))
    
    def geometry_function(self, r: float, theta: float, L: float = 3.5) -> float:
        """
        Calculate geometry function G(r,theta) for line source
        L: active length of source (mm) - typical 3.5mm for Ir-192
        """
        L_cm = L / 10.0  # Convert to cm
        r_cm = r / 10.0  # Convert to cm
        theta_rad = np.radians(theta)
        
        if abs(theta) < 1 or abs(theta - 180) < 1:  # Along source axis
            return 1.0 / (r_cm * r_cm - L_cm * L_cm / 4.0) if r_cm > L_cm/2 else 1.0 / (r_cm * r_cm)
        else:
            # For off-axis points
            return 1.0 / (r_cm * r_cm)  # Simplified point source approximation
    
    def radial_dose_function(self, r: float) -> float:
        """Get radial dose function g(r) value"""
        r_cm = r / 10.0  # Convert mm to cm
        return float(self.radial_dose_interp(r_cm))
    
    def anisotropy_function(self, r: float, theta: float) -> float:
        """Get anisotropy function F(r,theta) value"""
        # Ensure theta is in valid range
        theta = abs(theta) % 180
        return float(self.anisotropy_interp(theta))
    
    def calculate_dose_rate(self, dwell_pos: DwellPosition, calc_point: Tuple[float, float, float]) -> float:
        """
        Calculate dose rate at calculation point from single dwell position
        Using TG-43 formalism: D_rate = S_k * Lambda * G(r,theta) * g(r) * F(r,theta)
        """
        # Calculate distance and angle
        dx = calc_point[0] - dwell_pos.x
        dy = calc_point[1] - dwell_pos.y
        dz = calc_point[2] - dwell_pos.z
        
        r = np.sqrt(dx*dx + dy*dy + dz*dz)  # Distance in mm
        
        if r < 2.0:  # Avoid singularity near source
            r = 2.0
        
        # Calculate polar angle (angle from source axis)
        # Assuming source axis is along z-direction
        theta = np.degrees(np.arccos(abs(dz) / r)) if r > 0 else 90
        
        # TG-43 formalism components
        S_k = self.source_data.air_kerma_strength * 1e-6  # Convert to Gy·m²/h
        Lambda = self.source_data.dose_rate_constant  # Dose rate constant (cGy/h per U)
        G = self.geometry_function(r, theta)  # Geometry function
        g = self.radial_dose_function(r)  # Radial dose function
        F = self.anisotropy_function(r, theta)  # Anisotropy function
        
        # Calculate dose rate (cGy/h)
        dose_rate = S_k * Lambda * G * g * F * 1e6  # Scale back up
        
        return dose_rate

# Test the TG-43 implementation
print("\n--- Testing TG-43 Dose Calculator ---")
calculator = TG43DoseCalculator(ir192_source_data)

# Create test dwell position
test_dwell = DwellPosition(x=0, y=0, z=0, channel=1, position_number=1)

# Test calculation at different distances
print("Testing dose rate calculation at different distances:")
test_distances = [10, 20, 30, 50]  # mm
for distance in test_distances:
    calc_point = (distance, 0, 0)  # Point on x-axis
    dose_rate = calculator.calculate_dose_rate(test_dwell, calc_point)
    print(f"Distance: {distance:2d}mm → Dose rate: {dose_rate:8.2f} cGy/h")

# Test at different angles
print("\nTesting dose rate at different angles (20mm distance):")
test_angles = [0, 30, 60, 90]  # degrees
for angle_deg in test_angles:
    angle_rad = np.radians(angle_deg)
    calc_point = (20 * np.sin(angle_rad), 0, 20 * np.cos(angle_rad))
    dose_rate = calculator.calculate_dose_rate(test_dwell, calc_point)
    print(f"Angle: {angle_deg:2d}° → Dose rate: {dose_rate:8.2f} cGy/h")

print("\n✓ TG-43 dose calculator implemented and tested successfully!")