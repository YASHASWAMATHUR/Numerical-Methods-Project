# Part 2: Implementing optimization algorithms and treatment planning
print("\n=== IMPLEMENTING OPTIMIZATION ALGORITHMS ===")

class BrachytherapyPlan:
    """Represents a complete brachytherapy treatment plan"""
    
    def __init__(self, dwell_positions: List[DwellPosition], dwell_times: List[float], 
                 target_points: List[Tuple[float, float, float]], 
                 oar_points: List[Tuple[float, float, float]] = None):
        self.dwell_positions = dwell_positions
        self.dwell_times = dwell_times  # seconds
        self.target_points = target_points  # Planning Target Volume (PTV) points
        self.oar_points = oar_points or []  # Organs at Risk (OAR) points
        
    def calculate_total_dose(self, calc_point: Tuple[float, float, float], 
                           calculator: TG43DoseCalculator) -> float:
        """Calculate total dose at a point from all dwell positions"""
        total_dose = 0.0
        
        for i, dwell_pos in enumerate(self.dwell_positions):
            if i < len(self.dwell_times) and self.dwell_times[i] > 0:
                dose_rate = calculator.calculate_dose_rate(dwell_pos, calc_point)
                # Convert dose rate (cGy/h) to dose (cGy) using dwell time (seconds)
                dose = dose_rate * self.dwell_times[i] / 3600.0  # Convert hours to seconds
                total_dose += dose
                
        return total_dose

class BrachytherapyOptimizer:
    """Optimization algorithms for brachytherapy treatment planning"""
    
    def __init__(self, calculator: TG43DoseCalculator, prescription_dose: float = 600.0):
        self.calculator = calculator
        self.prescription_dose = prescription_dose  # cGy
        
    def objective_function(self, dwell_times: np.ndarray, plan: BrachytherapyPlan) -> float:
        """
        Objective function for optimization (to be minimized)
        Implements a simplified Linear Penalty Model (LPM)
        """
        # Update plan with new dwell times
        plan.dwell_times = dwell_times.tolist()
        
        total_penalty = 0.0
        
        # Target coverage penalty (underdosing)
        target_weight = 10.0
        for target_point in plan.target_points:
            dose = plan.calculate_total_dose(target_point, self.calculator)
            if dose < self.prescription_dose:
                # Penalty for underdosing target
                penalty = target_weight * (self.prescription_dose - dose) ** 2
                total_penalty += penalty
        
        # OAR sparing penalty (overdosing)
        oar_weight = 5.0
        oar_limit = self.prescription_dose * 0.7  # 70% of prescription as OAR limit
        for oar_point in plan.oar_points:
            dose = plan.calculate_total_dose(oar_point, self.calculator)
            if dose > oar_limit:
                # Penalty for overdosing OAR
                penalty = oar_weight * (dose - oar_limit) ** 2
                total_penalty += penalty
        
        # Regularization penalty (avoid very long dwell times)
        max_dwell_time = 100.0  # seconds
        regularization_weight = 0.1
        for dt in dwell_times:
            if dt > max_dwell_time:
                penalty = regularization_weight * (dt - max_dwell_time) ** 2
                total_penalty += penalty
        
        return total_penalty
    
    def optimize_ipsa_style(self, plan: BrachytherapyPlan, max_iterations: int = 100) -> BrachytherapyPlan:
        """
        Simplified IPSA-style optimization using scipy's optimization
        (Inverse Planning Simulated Annealing approach)
        """
        print(f"Starting IPSA-style optimization with {len(plan.dwell_positions)} dwell positions...")
        
        # Initial dwell times (uniform distribution)
        n_positions = len(plan.dwell_positions)
        initial_dwell_times = np.ones(n_positions) * 10.0  # 10 seconds each
        
        # Bounds for dwell times (0 to 100 seconds)
        bounds = [(0.0, 100.0) for _ in range(n_positions)]
        
        # Optimize using L-BFGS-B (good for constrained problems)
        result = minimize(
            fun=self.objective_function,
            x0=initial_dwell_times,
            args=(plan,),
            method='L-BFGS-B',
            bounds=bounds,
            options={'maxiter': max_iterations, 'disp': True}
        )
        
        # Update plan with optimized dwell times
        optimized_plan = BrachytherapyPlan(
            dwell_positions=plan.dwell_positions,
            dwell_times=result.x.tolist(),
            target_points=plan.target_points,
            oar_points=plan.oar_points
        )
        
        print(f"Optimization completed. Final objective value: {result.fun:.2f}")
        return optimized_plan
    
    def optimize_evolutionary(self, plan: BrachytherapyPlan, max_generations: int = 50) -> BrachytherapyPlan:
        """
        Evolutionary algorithm optimization (alternative to IPSA)
        """
        print(f"Starting evolutionary optimization...")
        
        n_positions = len(plan.dwell_positions)
        bounds = [(0.0, 100.0) for _ in range(n_positions)]
        
        # Use differential evolution
        result = differential_evolution(
            func=self.objective_function,
            bounds=bounds,
            args=(plan,),
            maxiter=max_generations,
            seed=42,
            disp=True
        )
        
        optimized_plan = BrachytherapyPlan(
            dwell_positions=plan.dwell_positions,
            dwell_times=result.x.tolist(),
            target_points=plan.target_points,
            oar_points=plan.oar_points
        )
        
        print(f"Evolutionary optimization completed. Final objective value: {result.fun:.2f}")
        return optimized_plan

# Create sample clinical case for testing
print("\n--- Creating Sample Clinical Case ---")

# Simulate a simple prostate HDR case with 2 catheters
print("Generating sample prostate HDR brachytherapy case...")

# Catheter 1: positions along z-axis (urethra region)
catheter1_positions = [
    DwellPosition(x=-5, y=0, z=z, channel=1, position_number=i)
    for i, z in enumerate(range(-20, 21, 5))  # 9 positions, 5mm apart
]

# Catheter 2: parallel catheter
catheter2_positions = [
    DwellPosition(x=5, y=0, z=z, channel=2, position_number=i)
    for i, z in enumerate(range(-20, 21, 5))  # 9 positions, 5mm apart
]

all_dwell_positions = catheter1_positions + catheter2_positions

# Define target points (PTV - planning target volume)
target_points = [
    (0, 0, z) for z in range(-15, 16, 5)  # Central target points
] + [
    (x, 0, 0) for x in [-10, -5, 5, 10]  # Lateral target points
]

# Define OAR points (organs at risk - e.g., rectum, urethra)
oar_points = [
    (-15, 0, z) for z in range(-10, 11, 5)  # Rectum points (left side)
] + [
    (0, 10, z) for z in range(-10, 11, 5)   # Bladder points (anterior)
]

print(f"Created clinical case with:")
print(f"- {len(all_dwell_positions)} dwell positions in {2} catheters")
print(f"- {len(target_points)} target volume points")
print(f"- {len(oar_points)} organ-at-risk points")

# Create initial treatment plan
initial_plan = BrachytherapyPlan(
    dwell_positions=all_dwell_positions,
    dwell_times=[15.0] * len(all_dwell_positions),  # Initial: 15 seconds each
    target_points=target_points,
    oar_points=oar_points
)

print(f"Initial plan total time: {sum(initial_plan.dwell_times):.1f} seconds")