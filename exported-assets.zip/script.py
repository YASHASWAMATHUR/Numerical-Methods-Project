# Brachytherapy Dose Planning and Optimization Mini Project
# Part 1: Setting up the project structure and implementing TG-43 dose calculation

import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import minimize, differential_evolution
from scipy.interpolate import interp2d, griddata
import pandas as pd
from dataclasses import dataclass
from typing import List, Tuple, Dict
import json

print("=== BRACHYTHERAPY DOSE PLANNING AND OPTIMIZATION MINI PROJECT ===")
print("Setting up project structure and implementing core algorithms...")

# Define data structures for brachytherapy planning
@dataclass
class DwellPosition:
    """Represents a dwell position in a catheter"""
    x: float  # mm
    y: float  # mm  
    z: float  # mm
    channel: int
    position_number: int

@dataclass
class SourceData:
    """TG-43 source specification data for Ir-192"""
    air_kerma_strength: float  # U (micro Gy m^2/h)
    dose_rate_constant: float  # Lambda (cGy/h/U)
    radial_dose_function_data: Dict  # g(r) vs r
    anisotropy_function_data: Dict   # F(r,theta) vs r,theta

# Create TG-43 source specification data for Ir-192 (typical HDR source)
ir192_source_data = SourceData(
    air_kerma_strength=40000,  # 40,000 U typical for new source
    dose_rate_constant=1.115,   # cGy/h/U for Ir-192
    radial_dose_function_data={
        # Distance (cm) : g(r) values
        0.1: 1.000, 0.25: 1.000, 0.5: 0.994, 0.75: 0.987, 1.0: 0.979,
        1.5: 0.964, 2.0: 0.948, 2.5: 0.932, 3.0: 0.915, 4.0: 0.881,
        5.0: 0.847, 6.0: 0.813, 7.0: 0.779, 8.0: 0.746, 10.0: 0.683
    },
    anisotropy_function_data={
        # Simplified 2D anisotropy data: (r_cm, theta_deg): F(r,theta)
        (0.5, 0): 0.685, (0.5, 10): 0.756, (0.5, 30): 0.932, (0.5, 90): 1.000,
        (1.0, 0): 0.703, (1.0, 10): 0.764, (1.0, 30): 0.940, (1.0, 90): 1.000,
        (2.0, 0): 0.720, (2.0, 10): 0.774, (2.0, 30): 0.946, (2.0, 90): 1.000,
        (5.0, 0): 0.730, (5.0, 10): 0.780, (5.0, 30): 0.950, (5.0, 90): 1.000,
    }
)

class TG43DoseCalculator:
    """Implementation of AAPM TG-43 dose calculation formalism"""
    
    def __init__(self, source_data: SourceData):
        self.source_data = source_data
        self.setup_interpolators()
    
    def setup_interpolators(self):
        """Setup interpolation functions for TG-43 parameters"""
        # Radial dose function interpolator
        r_values = list(self.source_data.radial_dose_function_data.keys())
        g_values = list(self.source_data.radial_dose_function_data.values())
        self.radial_dose_interp = interp2d([0], r_values, [g_values], kind='linear')
        
        # Anisotropy function interpolator (simplified 2D)
        aniso_data = self.source_data.anisotropy_function_data
        r_aniso = [key[0] for key in aniso_data.keys()]
        theta_aniso = [key[1] for key in aniso_data.keys()]
        f_aniso = list(aniso_data.values())
        
        # Create 2D interpolation points
        unique_r = sorted(list(set(r_aniso)))
        unique_theta = sorted(list(set(theta_aniso)))
        
        # Create grid for interpolation
        self.r_grid = np.array(unique_r)
        self.theta_grid = np.array(unique_theta)
        self.f_grid = np.zeros((len(unique_r), len(unique_theta)))
        
        for i, r in enumerate(unique_r):
            for j, theta in enumerate(unique_theta):
                if (r, theta) in aniso_data:
                    self.f_grid[i, j] = aniso_data[(r, theta)]
                else:
                    # Interpolate missing values
                    self.f_grid[i, j] = 1.0  # Default value
    
    def geometry_function(self, r: float, theta: float, L: float = 3.5) -> float:
        """
        Calculate geometry function G(r,theta) for line source
        L: active length of source (mm) - typical 3.5mm for Ir-192
        """
        L_cm = L / 10.0  # Convert to cm
        r_cm = r / 10.0  # Convert to cm
        theta_rad = np.radians(theta)
        
        if theta == 0 or theta == 180:
            return 1.0 / (r_cm * r_cm - L_cm * L_cm / 4.0)
        else:
            beta = np.arctan((L_cm/2.0 - r_cm * np.cos(theta_rad)) / (r_cm * np.sin(theta_rad)))
            alpha = np.arctan((L_cm/2.0 + r_cm * np.cos(theta_rad)) / (r_cm * np.sin(theta_rad)))
            return (beta - alpha) / (L_cm * r_cm * np.sin(theta_rad))
    
    def radial_dose_function(self, r: float) -> float:
        """Get radial dose function g(r) value"""
        r_cm = r / 10.0  # Convert mm to cm
        r_values = list(self.source_data.radial_dose_function_data.keys())
        g_values = list(self.source_data.radial_dose_function_data.values())
        
        if r_cm <= min(r_values):
            return g_values[0]
        elif r_cm >= max(r_values):
            return g_values[-1]
        else:
            return float(np.interp(r_cm, r_values, g_values))
    
    def anisotropy_function(self, r: float, theta: float) -> float:
        """Get anisotropy function F(r,theta) value"""
        r_cm = r / 10.0  # Convert mm to cm
        
        # Simple interpolation using nearest neighbor for this demo
        closest_r_idx = np.argmin(np.abs(self.r_grid - r_cm))
        closest_theta_idx = np.argmin(np.abs(self.theta_grid - theta))
        
        return float(self.f_grid[closest_r_idx, closest_theta_idx])
    
    def calculate_dose_rate(self, dwell_pos: DwellPosition, calc_point: Tuple[float, float, float]) -> float:
        """
        Calculate dose rate at calculation point from single dwell position
        Using TG-43 formalism: D_rate = S_k * Lambda * G(r,theta) * g(r) * F(r,theta)
        """
        # Calculate distance and angle
        dx = calc_point[0] - dwell_pos.x
        dy = calc_point[1] - dwell_pos.y
        dz = calc_point[2] - dwell_pos.z
        
        r = np.sqrt(dx*dx + dy*dy + dz*dz)  # Distance in mm
        
        if r < 1.0:  # Avoid singularity near source
            r = 1.0
        
        # Calculate polar angle (simplified for demonstration)
        theta = np.degrees(np.arccos(abs(dz) / r)) if r > 0 else 0
        
        # TG-43 formalism components
        S_k = self.source_data.air_kerma_strength  # Air kerma strength
        Lambda = self.source_data.dose_rate_constant  # Dose rate constant
        G = self.geometry_function(r, theta)  # Geometry function
        g = self.radial_dose_function(r)  # Radial dose function
        F = self.anisotropy_function(r, theta)  # Anisotropy function
        
        # Calculate dose rate (cGy/h)
        dose_rate = S_k * Lambda * G * g * F
        
        return dose_rate

# Test the TG-43 implementation
print("\n--- Testing TG-43 Dose Calculator ---")
calculator = TG43DoseCalculator(ir192_source_data)

# Create test dwell position
test_dwell = DwellPosition(x=0, y=0, z=0, channel=1, position_number=1)

# Test calculation at different distances
test_distances = [10, 20, 30, 50]  # mm
for distance in test_distances:
    calc_point = (distance, 0, 0)  # Point on x-axis
    dose_rate = calculator.calculate_dose_rate(test_dwell, calc_point)
    print(f"Dose rate at {distance}mm: {dose_rate:.2f} cGy/h")

print("\nTG-43 dose calculator implementation completed successfully!")