import plotly.graph_objects as go
import pandas as pd

# Data from the provided JSON
data = {
    "plan_type": ["Initial", "IPSA-Optimized"], 
    "target_mean_dose": [4044.9, 1214.1], 
    "target_min_dose": [2360.1, 678.6], 
    "oar_mean_dose": [1209.5, 369.2], 
    "total_treatment_time": [270.0, 81.8]
}

# Create DataFrame
df = pd.DataFrame(data)

# Define metric categories and their abbreviated labels
metrics = ['target_mean_dose', 'target_min_dose', 'oar_mean_dose', 'total_treatment_time']
metric_labels = ['Target Mean', 'Target Min', 'OAR Mean', 'Treatment Time']

# Brand colors
colors = ['#1FB8CD', '#DB4545']

# Create the figure
fig = go.Figure()

# Add bars for each plan type
for i, plan in enumerate(df['plan_type']):
    values = []
    for metric in metrics:
        value = df[df['plan_type'] == plan][metric].iloc[0]
        # Abbreviate numbers using k for thousands
        if value >= 1000:
            values.append(f"{value/1000:.2f}k")
        else:
            values.append(f"{value:.2f}")
    
    # Get actual numeric values for the bar heights
    numeric_values = [df[df['plan_type'] == plan][metric].iloc[0] for metric in metrics]
    
    fig.add_trace(go.Bar(
        name=plan,
        x=metric_labels,
        y=numeric_values,
        text=values,
        textposition='auto',
        marker_color=colors[i],
        cliponaxis=False
    ))

# Update layout
fig.update_layout(
    title="Brachytherapy Dose Metrics Comparison",
    xaxis_title="Metrics",
    yaxis_title="Values",
    barmode='group',
    legend=dict(orientation='h', yanchor='bottom', y=1.05, xanchor='center', x=0.5)
)

# Save the chart
fig.write_image("brachytherapy_comparison.png")